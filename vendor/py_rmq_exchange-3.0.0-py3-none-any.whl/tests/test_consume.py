#!/usr/bin/env python3
# pylint: disable=line-too-long, missing-function-docstring, logging-fstring-interpolation
# pylint: disable=too-many-locals, broad-except, too-many-arguments, raise-missing-from
"""
    py-rmq-exchange echo test
"""
import functools
import logging
import queue
import json
import threading
import time

from py_rmq_exchange import ExchangeThread, AsyncExchange

log_filename = "test_echo_consume.log"
rmq_server_address = "10.9.21.23"
rmq_server_port = 5672
rmq_exchange_1 = "td_receive_v2"
rmq_exchange_2 = "td_send_v2"
rmq_queue_1 = "test_td_receive_v2"
rmq_queue_2 = "test_td_send_v2"


logging.root.handlers = []
logging.basicConfig(
    level=logging.INFO,
    # level=logging.DEBUG,
    format="%(asctime)s level=%(levelname)s t=%(threadName)s function=%(name)s.%(funcName)s %(message)s",
    handlers=[
        logging.FileHandler(filename=log_filename),
        logging.StreamHandler()
    ]
)

logging.getLogger("pika").setLevel(logging.DEBUG)



def consumer_callback(channel, method, properties, body, *args, **kwargs):
    # logging.debug(f"Received inbound event: exchange={event['method'].exchange} routing_key={event['method'].routing_key} delivery_tag={event['method'].delivery_tag} event={event}")
    # [ logging.info(f"*" * 10) for _ in range(3) ] 

    logging.info(f"Received inbound event: channel={channel} delivery_tag={method.delivery_tag} body={body} args={args} kwargs={kwargs}")
    logging.info(f"*** channel={channel.is_open}")
    logging.info(f"*** channel.connection={channel.connection.is_open}")
    logging.info(f"*** thread={threading.current_thread().name}")
    # logging.info(f"Received inbound event: args={args} kwargs={kwargs}")
    # event_body_json = json.loads(event['body'])
    
    time.sleep(15)

    # for idx in range(15):
    #     logging.info(f"Processing message {method.delivery_tag}, step {idx+1}")
    #     time.sleep(0.1)

    # result = channel.basic_ack(delivery_tag=method.delivery_tag)
    result = channel.basic_ack(delivery_tag=method.delivery_tag)
    # ack_callback = functools.partial(channel.basic_ack, delivery_tag=method.delivery_tag)
    # result = channel.connection.add_callback_threadsafe(ack_callback)

    logging.info(f"ACK inbound event: delivery_tag={method.delivery_tag} result={result}")
    # event['channel'].basic_ack(delivery_tag=event['method'].delivery_tag)

    # body = {'loop': time.time(),}
    # payload = {
    #     'body': json.dumps(body),
    #     'routing_key': "route_9000",
    # }
    
    # time.sleep(0.3)
    # publish_queue.put(payload)

    return True


def get_async_exchange():
    consumer_1 = AsyncExchange(host=rmq_server_address, port=rmq_server_port, heartbeat=5)
    consumer_1.setup_consumer(
        exchange=rmq_exchange_1,
        exchange_type='fanout',
        on_message_callback=consumer_callback,
        queue=rmq_queue_1,
        exclusive=False,
        auto_ack=False,
        prefetch_count=100,
    )
    consumer_1.start()



def test_main():
    logging.info("Initialising exchange threads")

    logging.info("Setting up consumer #1")
    consumer_instance_1 = threading.Thread(target=get_async_exchange, args=())
    consumer_instance_1.name = "consumer_insatance_1_thread"
    consumer_instance_1.start()


#     logging.info("Setting up consumer #2")
#     consumer_2 = ExchangeThread(rmq_server_address=rmq_server_address, rmq_server_port=rmq_server_port)
#     consumer_2.setup_consumer(
#         exchange=rmq_exchange_2,
#         on_message_callback=consumer_callback,
#         queue_name=rmq_queue_2,
#         exclusive=False,
#         auto_ack=True,
#     )

#     consumer_1.start()
# #    consumer_2.start()

if __name__ == '__main__':
    test_main()
