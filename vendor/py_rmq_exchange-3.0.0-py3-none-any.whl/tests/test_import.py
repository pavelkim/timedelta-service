#!/usr/bin/env python3
# pylint: disable=line-too-long, missing-function-docstring, logging-fstring-interpolation
# pylint: disable=too-many-locals, broad-except, too-many-arguments, raise-missing-from
"""
    py-rmq-exchange module
"""

from py_rmq_exchange import ExchangeThread


def test_instance():
    exchange = ExchangeThread(rmq_server_address="localhost")

