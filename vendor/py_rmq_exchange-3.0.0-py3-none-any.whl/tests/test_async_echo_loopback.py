#!/usr/bin/env python3
# pylint: disable=line-too-long, missing-function-docstring, logging-fstring-interpolation
# pylint: disable=too-many-locals, broad-except, too-many-arguments, raise-missing-from
"""
    py-rmq-exchange async echo test
"""
import logging
import json
import time
import signal
import sys
import asyncio

from py_rmq_exchange.exchange import AsyncExchange


log_filename = "test_async_echo_loopback.log"
rmq_server_address = "10.9.21.23"
rmq_exchange = "test_async_echo_loopback"
rmq_queue_1 = "test_async_a"
rmq_queue_2 = "test_async_b"


logging.root.handlers = []
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s function=%(name)s.%(funcName)s level=%(levelname)s %(message)s",
    handlers=[
        logging.FileHandler(filename=log_filename),
        logging.StreamHandler()
    ]
)


# Global references for cleanup
publisher = None
consumer = None
consumer_2 = None


async def consumer_callback(event):
    logging.info(f"Received inbound event: routing_key={event['method'].routing_key} delivery_tag={event['method'].delivery_tag}")
    

    # NEVER block in callbacks - no time.sleep()!
    # This is an event-driven system running in pika's IOLoop thread
    
    # Optionally publish back (commenting out to avoid feedback loop)
    if publisher:
        body = {'loop': time.time(),}
        publisher.publish(json.dumps(body), routing_key="route_9000")

    # Manual ACK first
    await event['channel'].basic_ack(delivery_tag=event['method'].delivery_tag)

    return True


def signal_handler(sig, frame):
    """Handle graceful shutdown"""
    logging.info("Shutdown signal received, stopping...")
    
    if consumer:
        consumer.stop()
    if consumer_2:
        consumer_2.stop()
    if publisher:
        publisher.stop()
    
    sys.exit(0)


async def test_main():
    global publisher, consumer
    
    logging.info("Initialising async exchange")

    logging.info("Setting up publisher")
    publisher = AsyncExchange(rmq_server_address=rmq_server_address, name="AsyncPublisher")
    publisher.setup_publisher(
        exchange=rmq_exchange,
    )

    logging.info("Setting up consumer")
    consumer = AsyncExchange(rmq_server_address=rmq_server_address, name="AsyncConsumer")
    consumer.setup_consumer(
        exchange=rmq_exchange,
        on_message_callback=consumer_callback,
        auto_ack=False,
    )

    # Setup signal handler for graceful shutdown
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    # Start both (non-blocking)
    publisher.start()
    consumer.start()
    
    logging.info("Publisher and consumer started, running...")
    
    # Keep running
    try:
        while True:
            await asyncio.sleep(1)
    except KeyboardInterrupt:
        logging.info("KeyboardInterrupt received")
        signal_handler(None, None)


async def test_two_consumers():
    global publisher, consumer, consumer_2
    
    logging.info("Initialising async exchanges")

    logging.info("Setting up publisher")
    publisher = AsyncExchange(
        rmq_server_address=rmq_server_address, name="AsyncPublisher",
        rmq_username="dev_local", rmq_password="dev_local",
        )
    publisher.setup_publisher(
        exchange=rmq_exchange,
    )
    publisher.start()

    logging.info("Setting up consumer #1")
    consumer = AsyncExchange(
        rmq_server_address=rmq_server_address, name="AsyncConsumer1",
        rmq_username="dev_local", rmq_password="dev_local",
    )
    consumer.setup_consumer(
        exchange=rmq_exchange,
        on_message_callback=consumer_callback,
        queue_name=rmq_queue_1,
        exclusive=False,
        auto_ack=False,
    )

    logging.info("Setting up consumer #2")
    consumer_2 = AsyncExchange(
        rmq_server_address=rmq_server_address, name="AsyncConsumer2",
        rmq_username="dev_local", rmq_password="dev_local",
        )
    consumer_2.setup_consumer(
        exchange=rmq_exchange,
        on_message_callback=consumer_callback,
        queue_name=rmq_queue_2,
        exclusive=False,
        auto_ack=False,
    )

    # Setup signal handler for graceful shutdown
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    # Start all exchanges (non-blocking)
    publisher.start()
    consumer.start()
    consumer_2.start()
    
    logging.info("All exchanges started")
    
    # Wait for connections to establish and channels to be ready
    logging.info("Waiting for publisher to be ready...")
    max_wait = 2
    waited = 0
    while not publisher.is_ready() and waited < max_wait:
        await asyncio.sleep(0.1)
        waited += 0.1
    
    if not publisher.is_ready():
        logging.error("Publisher not ready after 30 seconds")
        return
    
    logging.info(f"Publisher ready after {waited:.1f}s")
    
    # Wait for consumers to be ready
    logging.info("Waiting for consumers to be ready...")
    waited = 0
    while (not consumer.is_ready() or not consumer_2.is_ready()) and waited < max_wait:
        await asyncio.sleep(0.1)
        waited += 0.1
    
    logging.info(f"Consumers ready after {waited:.1f}s")
    
    # Publish initial message
    body = {'loop': time.time(),}
    publisher.publish(json.dumps(body), routing_key="route_9000")
    logging.info("Published initial message")
    
    # Keep running
    try:
        while True:
            await asyncio.sleep(1)
            body = {'loop': time.time(),}
            publisher.publish(json.dumps(body), routing_key="route_9001")

    except KeyboardInterrupt:
        logging.info("KeyboardInterrupt received")
        signal_handler(None, None)


if __name__ == '__main__':
    # asyncio.run(test_main())
    asyncio.run(test_two_consumers())
