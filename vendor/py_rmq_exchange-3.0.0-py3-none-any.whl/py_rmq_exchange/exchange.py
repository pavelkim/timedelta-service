#!/usr/bin/env python3
# pylint: disable=line-too-long, missing-function-docstring, logging-fstring-interpolation
# pylint: disable=too-many-locals, broad-except, too-many-arguments,
# raise-missing-from
"""
    RabbitMQ client

"""

import logging
import threading
import time
import queue
import asyncio

import pika
from pika.connection import Parameters
from pika.adapters.asyncio_connection import AsyncioConnection
from pyp8s import MetricsHandler


def retry(attempts=10, delay=None):

    def decorate(func):
        def wrap(*args, **kwargs):

            current_attempt = 0

            while True:
                current_attempt += 1
                logging.warning(f"Retry #{current_attempt} for function: {func}")

                try:
                    result = func(*args, **kwargs)
                    return result

                except Exception as e:
                    logging.error(f"Retry #{current_attempt} for function: {func} failed: {e}")

                    if attempts is not None:
                        if current_attempt >= attempts:
                            raise e

                    if delay is not None:
                        time.sleep(delay)

        return wrap

    return decorate


class ExchangeThread(threading.Thread):

    def __init__(self, rmq_server_uri=None,
                 rmq_server_address=None, 
                 rmq_server_port=5672,
                 rmq_username=None,
                 rmq_password=None,
                 rmq_virtual_host=Parameters.DEFAULT_VIRTUAL_HOST,
                 thread_name=None,
                 *args, **kwargs):
        super(ExchangeThread, self).__init__()

        if thread_name is None:
            self.name = "ExchangeThread"
        else:
            self.name = thread_name

        self.daemon = True

        self._thread_id = None
        self._self_check_thread_alive = True
        self.alive = True
        self.allow_reconnect = True

        self.is_consumer = None
        self.is_publisher = None

        self.consumer_kwargs = {}
        self.publisher_kwargs = {}

        self.rmq_server_uri = rmq_server_uri

        self.rmq_server_address = rmq_server_address
        self.rmq_server_port = rmq_server_port
        self.rmq_username = rmq_username
        self.rmq_password = rmq_password
        self.rmq_virtual_host = rmq_virtual_host
        self.rmq_credentials = None
        self.connection = None
        self.connection_parameters = None

        self.publish_queue = None
        self.publish_attempts_limit = 10

        self.channel = None
        self.queue = None
        self.exchange = None
        self.on_message_callback = None

        self.consumer_tag = None

        self.args = args
        self.kwargs = kwargs

        self.env = {}

        self.logger = logging.getLogger(self.name)

        MetricsHandler.init("py_rmq_exchange", "counter", "ExchangeThread metrics")
        MetricsHandler.init("py_rmq_exchange_conn", "counter", "ExchangeThread RabbitMQ connection related")
        MetricsHandler.init("py_rmq_exchange_queues", "gauge", "ExchangeThread queues state")
        MetricsHandler.init("py_rmq_exchange_errors", "counter", "ExchangeThread errors")

        self._connect()
        self._open_channel()

        self.self_check_thread = threading.Thread(target=self.self_check_wrapper, args=())
        self.self_check_thread.name = "self_check_thread"
        self.self_check_thread.start()


    def setup_consumer(self, exchange, on_message_callback,
        queue_name="", exclusive=True, auto_ack=True, exchange_type='fanout', durable=False,
        routing_key=None, routing_keys=None,
        prefetch_size=0, prefetch_count=0, global_qos=False,
        exchange_declare_arguments=None, queue_declare_arguments=None):

        self.logger.info(f"Setting up RabbitMQ consumer exchange={exchange} on_message_callback={on_message_callback}")
        MetricsHandler.inc("py_rmq_exchange", 1, mode="consumer", func="setup_consumer")

        if self.is_publisher:
            raise Exception("Already a publisher, can't setup consuming")

        self.is_consumer = True
        self.consumer_kwargs = locals()
        self.consumer_kwargs.pop('self')


        self.exchange = exchange
        self.queue_name = queue_name
        self.exclusive = exclusive
        self.auto_ack = auto_ack
        self.exchange_type = exchange_type
        self.on_message_callback = on_message_callback
        self.durable = durable

        self.prefetch_size = prefetch_size
        self.prefetch_count = prefetch_count
        self.global_qos = global_qos

        if exchange_declare_arguments is None:
            self.exchange_declare_arguments = {}
        else:
            self.exchange_declare_arguments = exchange_declare_arguments

        if queue_declare_arguments is None:
            self.queue_declare_arguments = {}
        else:
            self.queue_declare_arguments = queue_declare_arguments

        # TODO: Parametrise exchange_type
        self.logger.info(f"Declaring RabbitMQ fanout exchange")
        self.channel.exchange_declare(exchange=self.exchange, exchange_type=self.exchange_type, durable=self.durable, arguments=self.exchange_declare_arguments)
        MetricsHandler.inc("py_rmq_exchange", 1, mode="consumer", action="declared_exchange")

        self.logger.info(f"Declaring RabbitMQ exclusive queue")
        declared_queue = self.channel.queue_declare(queue=self.queue_name, durable=self.durable, exclusive=self.exclusive, arguments=self.queue_declare_arguments)
        self.queue = declared_queue.method.queue
        MetricsHandler.inc("py_rmq_exchange", 1, mode="consumer", action="declared_queue")

        self.logger.info(f"Setting up QoS for RabbitMQ queue")
        self.channel.basic_qos(prefetch_size=self.prefetch_size, prefetch_count=self.prefetch_count, global_qos=self.global_qos)

        if routing_keys:
            for routing_key_item in routing_keys:
                self.logger.info(f"Binding RabbitMQ exclusive queue={self.queue} to exchange={self.exchange} with routing_key={routing_key_item}")
                self.channel.queue_bind(queue=self.queue, exchange=self.exchange, routing_key=routing_key_item)
                MetricsHandler.inc("py_rmq_exchange", 1, mode="consumer", action="bound_queue")
        else:
            self.logger.info(f"Binding RabbitMQ exclusive queue={self.queue} to exchange={self.exchange} with routing_key={routing_key}")
            self.channel.queue_bind(queue=self.queue, exchange=self.exchange, routing_key=routing_key)
            MetricsHandler.inc("py_rmq_exchange", 1, mode="consumer", action="bound_queue")

        self.logger.info(f"Configuring RabbitMQ basic consume with queue={self.queue}")
        self.consumer_tag = self.channel.basic_consume(
            queue=self.queue,
            auto_ack=self.auto_ack,
            on_message_callback=self._on_message_callback
        )


    def setup_publisher(self, exchange, publish_queue=None, exchange_type='fanout',
        exchange_declare_arguments=None):

        self.logger.info(f"Setting up RabbitMQ publisher exchange={exchange} publish_queue={publish_queue}")
        MetricsHandler.inc("py_rmq_exchange", 1, mode="publisher", func="setup_publisher")

        if self.is_consumer:
            raise Exception("Already a consumer, can't setup publishing")

        self.is_publisher = True
        self.publisher_kwargs = locals()
        self.publisher_kwargs.pop('self')

        if publish_queue is not None:
            self.publish_queue = publish_queue

        self.exchange = exchange
        self.exchange_type = exchange_type

        if exchange_declare_arguments is None:
            self.exchange_declare_arguments = {}
        else:
            self.exchange_declare_arguments = exchange_declare_arguments

        self.logger.info(f"Declaring RabbitMQ fanout exchange")
        self.channel.exchange_declare(exchange=self.exchange, exchange_type=self.exchange_type, arguments=self.exchange_declare_arguments)
        MetricsHandler.inc("py_rmq_exchange", 1, mode="publisher", action="declared_exchange")
        # self.channel.queue_declare(queue=queue)


    @retry(attempts=None, delay=1)
    def _connect(self):

        self.logger.info(f"Connecting to RabbitMQ host={self.rmq_server_address}")
        MetricsHandler.inc("py_rmq_exchange_conn", 1, action="connection_attempt")

        if self.rmq_server_uri:
            self.logger.info(f"Using URI to connect to the RabbitMQ server")
            self.connection_parameters = pika.URLParameters(self.rmq_server_uri)

        elif self.rmq_server_address:
            self.logger.info(f"Using separate parameters to connect to the RabbitMQ server")

            connection_kwargs = {
                "host": self.rmq_server_address,
                "port": self.rmq_server_port,
                "virtual_host": self.rmq_virtual_host,
            }

            if self.rmq_username and self.rmq_password:
                connection_kwargs['credentials'] = pika.PlainCredentials(self.rmq_username, self.rmq_password)

            self.connection_parameters = (
                pika.ConnectionParameters(**connection_kwargs),
            )

        self.connection = pika.BlockingConnection(
            self.connection_parameters,
        )

        self.logger.info(f"Connection to RabbitMQ connection={self.connection}")

    def _open_channel(self):

        self.logger.info(f"Opening a channel in RabbitMQ")
        self.channel = self.connection.channel()
        self.logger.info(f"Opened a channel in RabbitMQ channel={self.channel}")

    def _disconnect(self):

        self.logger.info(f"Disconnecting from RabbitMQ")
        MetricsHandler.inc("py_rmq_exchange_conn", 1, action="disconnection")

        try:
            if self.connection.is_open:
                self.connection.close()
                self.logger.info(f"Closed connection to RabbitMQ connection={self.connection}")

            else:
                self.logger.warning(f"Connection already closed connection={self.connection}")

        except Exception as e:
            self.logger.exception(f"Error {e.__class__.__name__} while closing the connection: {e}")
            MetricsHandler.inc("py_rmq_exchange_errors", 1, subject="connection", reason="cantClose")

    def _close_channel(self):

        self.logger.info(f"Closing channel in RabbitMQ")
        try:
            if self.channel.is_open:
                self.channel.close()
                self.logger.info(f"Closed channel in RabbitMQ channel={self.channel}")

            else:
                self.logger.warning(f"Channel already closed channel={self.channel}")

        except Exception as e:
            self.logger.exception(f"Error {e.__class__.__name__} while closing the channel: {e}")
            MetricsHandler.inc("py_rmq_exchange_errors", 1, subject="channel", reason="cantClose")

    def _reconnect(self):

        self.logger.info("Reinitialising connection to RabbitMQ")

        if not self.alive:
            self.logger.info("Reconnecting not allowed as the thread was marked as not alive")
            return None

        MetricsHandler.inc("py_rmq_exchange_conn", 1, action="reconnecting")
        self._close_channel()
        self._disconnect()

        self._connect()
        self._open_channel()
        
        if self.is_consumer:
            self.setup_consumer(**self.consumer_kwargs)

        elif self.is_publisher:
            self.setup_publisher(**self.publisher_kwargs)

        else:
            self.logger.warning("Publisher/consumer flag not set, setup this manually.")

        return True

    def _on_message_callback(self, channel, method, properties, body):
        self.logger.debug(f"Received inbound event: channel={channel}, method={method}, properties={properties}, body={body}")
        self.logger.debug(f"Additional parameters: args={self.args}, kwargs={self.kwargs}")

        self.logger.debug(f"Received message: exchange={method.exchange} body={body}")
        MetricsHandler.inc("py_rmq_exchange", 1, mode="consumer", func="_on_message_callback")
        MetricsHandler.inc("py_rmq_exchange", 1, mode="consumer", event="incoming_message")

        self.on_message_callback(
            {
                "channel": channel,
                "method": method,
                "properties": properties,
                "body": body,
            }
        )

        return True


    def self_check_wrapper(self):

        while self._self_check_thread_alive:
            try:

                if not self.self_check:
                    self.logger.error(f"Self check thread doing a reconnect")
                    MetricsHandler.inc("py_rmq_exchange_self_check", 1, result="fail")
                    MetricsHandler.inc("py_rmq_exchange_errors", 1, subject="self_check", reason="failed")
                    self._reconnect()

                else:
                    MetricsHandler.inc("py_rmq_exchange_self_check", 1, result="success")


            except Exception as e:
                self.logger.error(f"Self check thread tripped {e.__class__.__name__}: {e}")
                MetricsHandler.inc("py_rmq_exchange_errors", 1, subject="self_check", reason="exception")

            time.sleep(0.5)


    def self_check(self):

        if self.publish_queue is not None:
            MetricsHandler.set("py_rmq_exchange_queues", self.publish_queue.qsize(), queue="publish_queue")
            if self.publish_queue.qsize() > 100:
                self.logger.error(f"Publish Queue() is blowing up: {self.publish_queue.qsize()}")

        if not self.connection.is_open:
            MetricsHandler.inc("py_rmq_exchange_errors", 1, subject="connection", reason="not_open")
            self.logger.error(f"self.connection is not open: {self.connection}")
            return False

        if not self.channel.is_open:
            MetricsHandler.inc("py_rmq_exchange_errors", 1, subject="channel", reason="not_open")
            self.logger.error(f"self.channel is not open: {self.channel}")
            return False

        return True

    def publish(self, body, routing_key=''):

        self.logger.debug(f"Publishing a message exchange={self.exchange} routing_key={routing_key}")
        MetricsHandler.inc("py_rmq_exchange", 1, mode="publisher", event="outbound_message")
        attempts = 0

        while attempts < self.publish_attempts_limit:

            attempts += 1

            try:
                MetricsHandler.inc("py_rmq_exchange", 1, mode="publisher", action="publish_attempt")
                self.channel.basic_publish(
                    exchange=self.exchange,
                    routing_key=routing_key,
                    body=body,
                )

                self.logger.debug(f"Published message: exchange={self.exchange} routing_key={routing_key} body={body}")
                MetricsHandler.inc("py_rmq_exchange", 1, mode="publisher", action="publish_success")

                return True

            except Exception as e:
                self.logger.exception(f"Couldn't publish message: {e} (retry: {attempts}/{self.publish_attempts_limit})")
                MetricsHandler.inc("py_rmq_exchange_errors", 1, subject="publisher", reason="cant_publish")
                self._reconnect()

        # self.logger.warning(f"Returning unpublished message into publish_queue: body={body}")
        # self.publish_queue.put(body)
        MetricsHandler.inc("py_rmq_exchange_errors", 1, subject="publisher", reason="publish_retries_over")
        raise Exception("Couldn't publish message.")

    def run(self):

        while self.alive:
            MetricsHandler.inc("py_rmq_exchange", 1, subject="ExchangeThread", actoin="main_loop")
            try:

                if self.is_consumer:
                    self.logger.info("ExchangeThread started consuming")
                    
                    MetricsHandler.inc("py_rmq_exchange", 1, mode="consumer", action="start_consuming")
                    self.channel.start_consuming()
                    self.logger.warning(f"Consuming stopped (without an exception)")

                elif self.is_publisher and self.publish_queue is not None:
                    self.logger.debug("ExchangeThread started publishing")

                    payload = self.publish_queue.get(10)
                    MetricsHandler.inc("py_rmq_exchange", 1, mode="publisher", action="got_from_queue")
                    self.logger.debug(f"Picked up from the publish queue: type={type(payload)} payload={payload}")

                    if payload:

                        _payload_body = None
                        _payload_routing_key = None

                        if 'body' in payload:

                            if not isinstance(payload['body'], (str, bytes,)):
                                raise Exception("Payload body must be of type str or bytes")

                            _payload_body = payload['body']

                        else:
                            raise Exception("Payload must contain 'body'")

                        if 'routing_key' in payload:
                            _payload_routing_key = payload['routing_key']
                        else:
                            _payload_routing_key = ""

                        self.publish(body=_payload_body, routing_key=_payload_routing_key)
                        self.logger.debug(f"Published message: routing_key={_payload_routing_key} body={_payload_body}")

                else:
                    MetricsHandler.inc("py_rmq_exchange_errors", 1, subject="ExchangeThread", reason="cant_start_thread")
                    raise Exception(f"Can't start thread: is_publisher={self.is_publisher}, publish_queue_ready={self.publish_queue is not None}, is_consumer={self.is_consumer}")

            except pika.exceptions.ChannelClosed as e:
                MetricsHandler.inc("py_rmq_exchange_errors", 1, subject="pika", reason="ChannelClosed")
                self.logger.error(f"RabbitMQ Channel has been closed: {e}")
                self._reconnect()

            except Exception as e:
                self.logger.exception(f"ExchangeThread tripped {e.__class__.__name__}: {str(e)}")
                MetricsHandler.inc("py_rmq_exchange_errors", 1, subject="ExchangeThread", reason="exception")

                if not self.self_check():
                    MetricsHandler.inc("py_rmq_exchange_errors", 1, subject="ExchangeThread", reason="selfcheck_failed")
                    self.logger.error("Self-check didn't pass after an exception, reconnecting")
                    self._reconnect()

                time.sleep(0.3)

    def stop(self):
        self.logger.warning("Stopping ExchangeThread")
        MetricsHandler.inc("py_rmq_exchange", 1, action="stop")
        self.alive = False
        self.allow_reconnect = False
        self._self_check_thread_alive = False

        try:
            self.self_check_thread.join(10)

        except Exception as e:
            self.logger.error(f"Couldn't join self-check thread {e.__class__.__name__}: {str(e)}")

        try:
            if self.is_consumer:
                self.logger.warning("Cancelling basic consumer")
                MetricsHandler.inc("py_rmq_exchange", 1, mode="consumer", action="basic_cancel")
                self.channel.basic_cancel(consumer_tag=self.consumer_tag)

        except Exception as e:
            self.logger.error(f"Couldn't perform basic_cancel {e.__class__.__name__}: {str(e)}")

        self.logger.warning("Disconnecting")
        self._disconnect()
        self.logger.warning("Disconnected")


    def get_id(self):

        if self._thread_id is not None:
            return self._thread_id

        for thread_id, thread in threading._active.items():
            if thread is self:
                self._thread_id = thread_id

        return self._thread_id


# class AsyncExchange:
#     """Async RabbitMQ client using pika's SelectConnection with asyncio integration"""

#     def __init__(self, rmq_server_uri=None,
#                  rmq_server_address=None,
#                  rmq_server_port=5672,
#                  rmq_username=None,
#                  rmq_password=None,
#                  rmq_virtual_host=Parameters.DEFAULT_VIRTUAL_HOST,
#                  name=None,
#                  heartbeat_interval=10,
#                  *args, **kwargs):

#         self.name = name or "AsyncExchange"
        
#         self.alive = True
#         self.allow_reconnect = True
        
#         self.is_consumer = None
#         self.is_publisher = None
        
#         self.consumer_kwargs = {}
#         self.publisher_kwargs = {}
        
#         self.rmq_server_uri = rmq_server_uri
#         self.rmq_server_address = rmq_server_address
#         self.rmq_server_port = rmq_server_port
#         self.rmq_username = rmq_username
#         self.rmq_password = rmq_password
#         self.rmq_virtual_host = rmq_virtual_host
        
#         self.connection = None
#         self.connection_parameters = None
#         self.channel = None
        
#         self.queue = None
#         self.exchange = None
#         self.on_message_callback = None
#         self.consumer_tag = None
        
#         self.publish_queue = []
#         self.publish_attempts_limit = 10
        
#         self.heartbeat_interval = heartbeat_interval
#         self._heartbeat_timer = None
#         self._reconnect_delay = 0.2
#         self._is_connecting = False
#         self._is_closing = False
        
#         # Asyncio integration
#         self._loop = None
#         self._ioloop_thread = None
#         self._ioloop_running = False
        
#         self.args = args
#         self.kwargs = kwargs
        
#         self.logger = logging.getLogger(self.name)
        
#         MetricsHandler.init("py_rmq_exchange_async", "counter", "AsyncExchange metrics")
#         MetricsHandler.init("py_rmq_exchange_async_conn", "counter", "AsyncExchange RabbitMQ connection related")
#         MetricsHandler.init("py_rmq_exchange_async_queues", "gauge", "AsyncExchange queues state")
#         MetricsHandler.init("py_rmq_exchange_async_errors", "counter", "AsyncExchange errors")

#     def _build_connection_parameters(self):
#         """Build connection parameters"""
#         if self.rmq_server_uri:
#             self.logger.info("Using URI to connect to the RabbitMQ server")
#             return pika.URLParameters(self.rmq_server_uri)
        
#         elif self.rmq_server_address:
#             self.logger.info("Using separate parameters to connect to the RabbitMQ server")
            
#             connection_kwargs = {
#                 "host": self.rmq_server_address,
#                 "port": self.rmq_server_port,
#                 "virtual_host": self.rmq_virtual_host,
#             }
            
#             if self.rmq_username and self.rmq_password:
#                 connection_kwargs['credentials'] = pika.PlainCredentials(
#                     self.rmq_username, self.rmq_password
#                 )
            
#             return pika.ConnectionParameters(**connection_kwargs)
        
#         raise ValueError("Either rmq_server_uri or rmq_server_address must be provided")

#     def _connect(self):
#         """Establish connection to RabbitMQ"""
#         if self._is_connecting:
#             self.logger.warning("Connection attempt already in progress")
#             return
        
#         self._is_connecting = True
#         self.logger.info(f"Connecting to RabbitMQ host={self.rmq_server_address}")
#         MetricsHandler.inc("py_rmq_exchange_async_conn", 1, action="connection_attempt")
        
#         try:
#             self.connection_parameters = self._build_connection_parameters()
#             self.connection = AsyncioConnection(
#                 parameters=self.connection_parameters,
#                 on_open_callback=self._on_connection_open,
#                 on_open_error_callback=self._on_connection_open_error,
#                 on_close_callback=self._on_connection_closed
#             )
#             self.logger.info(f"Connection to RabbitMQ created with the callbacks")

#         except Exception as e:
#             self.logger.exception(f"Failed to create connection: {e}")
#             self._is_connecting = False
#             MetricsHandler.inc("py_rmq_exchange_async_errors", 1, subject="connection", reason="create_failed")
#             self._schedule_reconnect()

#     def _on_connection_open(self, connection):
#         """Called when connection is established"""
#         self.logger.info("Connection opened successfully")
#         self._is_connecting = False
#         MetricsHandler.inc("py_rmq_exchange_async_conn", 1, action="connection_opened")
#         self._open_channel()

#     def _on_connection_open_error(self, connection, error):
#         """Called when connection fails to open"""
#         self.logger.error(f"Connection open failed: {error}")
#         self._is_connecting = False
#         MetricsHandler.inc("py_rmq_exchange_async_errors", 1, subject="connection", reason="open_failed")
#         self._schedule_reconnect()

#     def _on_connection_closed(self, connection, reason):
#         """Called when connection is closed"""
#         self.logger.warning(f"Connection closed: {reason}")
#         MetricsHandler.inc("py_rmq_exchange_async_conn", 1, action="connection_closed")
        
#         self.channel = None
        
#         if self._is_closing:
#             if self._ioloop_running:
#                 self.connection.ioloop.stop()
#         elif self.allow_reconnect and self.alive:
#             self._schedule_reconnect()

#     def _open_channel(self):
#         """Open a channel"""
#         self.logger.info("Opening channel")
#         self.connection.channel(on_open_callback=self._on_channel_open)

#     def _on_channel_open(self, channel):
#         """Called when channel is opened"""
#         self.logger.info("Channel opened successfully")
#         self.channel = channel
#         self.channel.add_on_close_callback(self._on_channel_closed)
        
#         # Re-setup consumer or publisher after reconnection
#         if self.is_consumer and self.consumer_kwargs:
#             self._setup_consumer_internal(**self.consumer_kwargs)
#         elif self.is_publisher and self.publisher_kwargs:
#             self._setup_publisher_internal(**self.publisher_kwargs)

#         # Start health check
#         self._schedule_heartbeat()

#     def _on_channel_closed(self, channel, reason):
#         """Called when channel is closed"""
#         self.logger.warning(f"Channel closed: {reason}")
#         MetricsHandler.inc("py_rmq_exchange_async_errors", 1, subject="channel", reason="closed")
        
#         if not self._is_closing:
#             # Only try to close connection if it's not already closed
#             if self.connection and not self.connection.is_closed:
#                 try:
#                     self.connection.close()
#                 except Exception as e:
#                     self.logger.debug(f"Error closing connection: {e}")

#     def _schedule_reconnect(self):
#         """Schedule a reconnection attempt"""
#         if not self.allow_reconnect:
#             self.logger.warning("Reconnecting not allowed, skipping reconnect")
#             return
        
#         if not self.alive:
#             self.logger.warning("The object is not alive, skipping reconnect")
#             return
        
#         self.logger.info(f"Scheduling reconnect in {self._reconnect_delay} seconds")
#         MetricsHandler.inc("py_rmq_exchange_async_conn", 1, action="reconnect_scheduled")
        
#         if self.connection and hasattr(self.connection, 'ioloop'):
#             self.connection.ioloop.call_later(self._reconnect_delay, self._reconnect)
#             self.logger.info("Reconnect scheduled on ioloop")
#         else:
#             self.logger.warning("Connection or ioloop not available, reconnecting immediately")
#             self._reconnect()
            
#     def _reconnect(self):
#         """Reconnect to RabbitMQ"""
#         self.logger.info("Reconnecting to RabbitMQ")
#         MetricsHandler.inc("py_rmq_exchange_async_conn", 1, action="reconnecting")
        
#         if self.connection and not self.connection.is_closed:
#             self.logger.info("Closing existing connection before reconnecting")
#             try:
#                 self.connection.close()
#                 self.logger.info("Existing connection closed")
#             except Exception as e:
#                 self.logger.error(f"Error closing connection during reconnect: {e}")

#         self._connect()

#     def setup_consumer(self, exchange, on_message_callback,
#                       queue_name="", exclusive=True, auto_ack=True,
#                       exchange_type='fanout', durable=False,
#                       routing_key=None, routing_keys=None,
#                       prefetch_size=0, prefetch_count=0, global_qos=False,
#                       exchange_declare_arguments=None, queue_declare_arguments=None):
#         """Setup consumer configuration"""
        
#         self.logger.info(f"Setting up RabbitMQ consumer exchange={exchange}")
#         MetricsHandler.inc("py_rmq_exchange_async", 1, mode="consumer", func="setup_consumer")
        
#         if self.is_publisher:
#             raise Exception("Already a publisher, can't setup consuming")
        
#         self.is_consumer = True
#         self.consumer_kwargs = {
#             'exchange': exchange,
#             'on_message_callback': on_message_callback,
#             'queue_name': queue_name,
#             'exclusive': exclusive,
#             'auto_ack': auto_ack,
#             'exchange_type': exchange_type,
#             'durable': durable,
#             'routing_key': routing_key,
#             'routing_keys': routing_keys,
#             'prefetch_size': prefetch_size,
#             'prefetch_count': prefetch_count,
#             'global_qos': global_qos,
#             'exchange_declare_arguments': exchange_declare_arguments,
#             'queue_declare_arguments': queue_declare_arguments,
#         }
        
#         if self.channel and self.channel.is_open:
#             self._setup_consumer_internal(**self.consumer_kwargs)

#     def _setup_consumer_internal(self, exchange, on_message_callback,
#                                  queue_name="", exclusive=True, auto_ack=True,
#                                  exchange_type='fanout', durable=False,
#                                  routing_key=None, routing_keys=None,
#                                  prefetch_size=0, prefetch_count=0, global_qos=False,
#                                  exchange_declare_arguments=None, queue_declare_arguments=None):
#         """Internal consumer setup with active channel"""
        
#         self.exchange = exchange
#         self.on_message_callback = on_message_callback
#         self.exchange_type = exchange_type
#         self.durable = durable
#         self.queue_name = queue_name
#         self.exclusive = exclusive
#         self.auto_ack = auto_ack
        
#         self.exchange_declare_arguments = exchange_declare_arguments or {}
#         self.queue_declare_arguments = queue_declare_arguments or {}
        
#         # Declare exchange
#         self.logger.info(f"Declaring RabbitMQ exchange: {self.exchange}")
#         self.channel.exchange_declare(
#             exchange=self.exchange,
#             exchange_type=self.exchange_type,
#             durable=self.durable,
#             arguments=self.exchange_declare_arguments,
#             callback=lambda frame: self._on_exchange_declared(
#                 frame, queue_name, exclusive, routing_key, routing_keys,
#                 prefetch_size, prefetch_count, global_qos
#             )
#         )

#     def _on_exchange_declared(self, frame, queue_name, exclusive, routing_key, routing_keys,
#                               prefetch_size, prefetch_count, global_qos):
#         """Called after exchange is declared"""
#         self.logger.info("Exchange declared successfully")
#         MetricsHandler.inc("py_rmq_exchange_async", 1, mode="consumer", action="declared_exchange")
        
#         # Declare queue
#         self.logger.info("Declaring RabbitMQ queue")
#         self.channel.queue_declare(
#             queue=queue_name,
#             durable=self.durable,
#             exclusive=exclusive,
#             arguments=self.queue_declare_arguments,
#             callback=lambda frame: self._on_queue_declared(
#                 frame, routing_key, routing_keys, prefetch_size, prefetch_count, global_qos
#             )
#         )

#     def _on_queue_declared(self, frame, routing_key, routing_keys,
#                            prefetch_size, prefetch_count, global_qos):
#         """Called after queue is declared"""
#         self.queue = frame.method.queue
#         self.logger.info(f"Queue declared successfully: {self.queue}")
#         MetricsHandler.inc("py_rmq_exchange_async", 1, mode="consumer", action="declared_queue")
        
#         # Set QoS
#         self.channel.basic_qos(
#             prefetch_size=prefetch_size,
#             prefetch_count=prefetch_count,
#             global_qos=global_qos,
#             callback=lambda frame: self._on_qos_set(frame, routing_key, routing_keys)
#         )

#     def _on_qos_set(self, frame, routing_key, routing_keys):
#         """Called after QoS is set"""
#         self.logger.info("QoS set successfully")
        
#         # Bind queue to exchange
#         if routing_keys:
#             self._bind_routing_keys = list(routing_keys)
#             self._bind_next_routing_key()
#         else:
#             self._bind_queue(routing_key or '')

#     def _bind_next_routing_key(self):
#         """Bind next routing key in the list"""
#         if self._bind_routing_keys:
#             rk = self._bind_routing_keys.pop(0)
#             self.logger.info(f"Binding queue to exchange with routing_key={rk}")
#             self.channel.queue_bind(
#                 queue=self.queue,
#                 exchange=self.exchange,
#                 routing_key=rk,
#                 callback=lambda frame: self._on_queue_bound(frame)
#             )
#         else:
#             # All bindings complete, start consuming
#             self._start_consuming()

#     def _bind_queue(self, routing_key):
#         """Bind queue with single routing key"""
#         self.logger.info(f"Binding queue to exchange with routing_key={routing_key}")
#         self.channel.queue_bind(
#             queue=self.queue,
#             exchange=self.exchange,
#             routing_key=routing_key,
#             callback=lambda frame: self._on_queue_bound_single(frame)
#         )

#     def _on_queue_bound(self, frame):
#         """Called after each queue binding"""
#         MetricsHandler.inc("py_rmq_exchange_async", 1, mode="consumer", action="bound_queue")
#         self._bind_next_routing_key()

#     def _on_queue_bound_single(self, frame):
#         """Called after single queue binding"""
#         MetricsHandler.inc("py_rmq_exchange_async", 1, mode="consumer", action="bound_queue")
#         self._start_consuming()

#     def _start_consuming(self):
#         """Start consuming messages"""
#         self.logger.info("Starting to consume messages")
#         self.consumer_tag = self.channel.basic_consume(
#             queue=self.queue,
#             on_message_callback=self._on_message,
#             auto_ack=self.auto_ack
#         )
#         MetricsHandler.inc("py_rmq_exchange_async", 1, mode="consumer", action="start_consuming")

#     def _on_message(self, channel, method, properties, body):
#         """Called when a message is received"""
#         self.logger.debug(f"Received message: exchange={method.exchange} body={body}")
#         MetricsHandler.inc("py_rmq_exchange_async", 1, mode="consumer", event="incoming_message")
        
#         try:
#             self.on_message_callback({
#                 "channel": channel,
#                 "method": method,
#                 "properties": properties,
#                 "body": body,
#             })
#         except Exception as e:
#             self.logger.exception(f"Error in message callback: {e}")
#             MetricsHandler.inc("py_rmq_exchange_async_errors", 1, subject="consumer", reason="callback_error")

#     def setup_publisher(self, exchange, exchange_type='fanout',
#                        exchange_declare_arguments=None):
#         """Setup publisher configuration"""
        
#         self.logger.info(f"Setting up RabbitMQ publisher exchange={exchange}")
#         MetricsHandler.inc("py_rmq_exchange_async", 1, mode="publisher", func="setup_publisher")
        
#         if self.is_consumer:
#             raise Exception("Already a consumer, can't setup publishing")
        
#         self.is_publisher = True
#         self.publisher_kwargs = {
#             'exchange': exchange,
#             'exchange_type': exchange_type,
#             'exchange_declare_arguments': exchange_declare_arguments,
#         }
        
#         if self.channel and self.channel.is_open:
#             self._setup_publisher_internal(**self.publisher_kwargs)

#     def _setup_publisher_internal(self, exchange, exchange_type='fanout',
#                                   exchange_declare_arguments=None):
#         """Internal publisher setup with active channel"""
        
#         self.exchange = exchange
#         self.exchange_type = exchange_type
#         self.exchange_declare_arguments = exchange_declare_arguments or {}
        
#         # Declare exchange
#         self.logger.info(f"Declaring RabbitMQ exchange: {self.exchange}")
#         self.channel.exchange_declare(
#             exchange=self.exchange,
#             exchange_type=self.exchange_type,
#             arguments=self.exchange_declare_arguments,
#             callback=self._on_publisher_exchange_declared
#         )

#     def _on_publisher_exchange_declared(self, frame):
#         """Called after publisher exchange is declared"""
#         self.logger.info("Publisher exchange declared successfully")
#         MetricsHandler.inc("py_rmq_exchange_async", 1, mode="publisher", action="declared_exchange")
        
#         # Process any queued messages
#         self._process_publish_queue()

#     def publish(self, body, routing_key=''):
#         """Publish a message"""
        
#         if not isinstance(body, (str, bytes)):
#             raise ValueError("Body must be str or bytes")
        
#         self.logger.debug(f"Publishing message: routing_key={routing_key}")
#         MetricsHandler.inc("py_rmq_exchange_async", 1, mode="publisher", event="outbound_message")
        
#         if not self.channel or not self.channel.is_open:
#             self.logger.warning("Channel not ready, queueing message")
#             self.publish_queue.append({'body': body, 'routing_key': routing_key})
#             MetricsHandler.inc("py_rmq_exchange_async", 1, mode="publisher", action="queued_message")
#             return False
        
#         try:
#             self.channel.basic_publish(
#                 exchange=self.exchange,
#                 routing_key=routing_key,
#                 body=body
#             )
#             self.logger.debug(f"Published message successfully")
#             MetricsHandler.inc("py_rmq_exchange_async", 1, mode="publisher", action="publish_success")
#             return True
        
#         except Exception as e:
#             self.logger.exception(f"Failed to publish message: {e}")
#             MetricsHandler.inc("py_rmq_exchange_async_errors", 1, subject="publisher", reason="publish_failed")
#             self.publish_queue.append({'body': body, 'routing_key': routing_key})
#             return False

#     def _process_publish_queue(self):
#         """Process queued publish messages"""
#         while self.publish_queue and self.channel and self.channel.is_open:
#             msg = self.publish_queue.pop(0)
#             self.publish(msg['body'], msg.get('routing_key', ''))

#     def _schedule_heartbeat(self):
#         """Schedule next heartbeat check"""
#         if self._heartbeat_timer:
#             try:
#                 self.connection.ioloop.remove_timeout(self._heartbeat_timer)
#             except Exception:
#                 pass
        
#         if self.alive and self.connection and hasattr(self.connection, 'ioloop'):
#             self._heartbeat_timer = self.connection.ioloop.call_later(
#                 self.heartbeat_interval,
#                 self._heartbeat_check
#             )

#     def _heartbeat_check(self):
#         """Perform health check"""
#         try:
#             if not self.alive:
#                 return
            
#             # Check connection and channel health
#             if not self.connection or self.connection.is_closed:
#                 self.logger.error("Health check: connection is closed")
#                 MetricsHandler.inc("py_rmq_exchange_async_errors", 1, subject="healthcheck", reason="connection_closed")
#                 self._schedule_reconnect()
#                 return
            
#             if not self.channel or self.channel.is_closed:
#                 self.logger.error("Health check: channel is closed")
#                 MetricsHandler.inc("py_rmq_exchange_async_errors", 1, subject="healthcheck", reason="channel_closed")
#                 self._open_channel()
#                 return
            
#             # Check publish queue size
#             if len(self.publish_queue) > 100:
#                 self.logger.warning(f"Publish queue growing: {len(self.publish_queue)}")
#                 MetricsHandler.set("py_rmq_exchange_async_queues", len(self.publish_queue), queue="publish_queue")
            
#             MetricsHandler.inc("py_rmq_exchange_async", 1, action="healthcheck_success")
            
#         except Exception as e:
#             self.logger.exception(f"Health check failed: {e}")
#             MetricsHandler.inc("py_rmq_exchange_async_errors", 1, subject="healthcheck", reason="exception")
        
#         finally:
#             self._schedule_heartbeat()

#     def start(self):
#         """Start the async exchange (non-blocking)"""
#         self.logger.info("Starting AsyncExchange")
        
#         # Start connection and IOLoop in a daemon thread
#         if not self._ioloop_thread or not self._ioloop_thread.is_alive():
#             self._ioloop_thread = threading.Thread(target=self._run_ioloop_thread, daemon=True)
#             self._ioloop_thread.name = f"{self.name}_IOLoop"
#             self._ioloop_thread.start()
#             self.logger.info("Started IOLoop thread")
    
#     def _run_ioloop_thread(self):
#         """Run pika's IOLoop in a dedicated thread"""
#         self.logger.info("IOLoop thread started")
#         self._ioloop_running = True
        
#         try:
#             # Start connection
#             self._connect()
            
#             # Start the IOLoop (this blocks until stopped)
#             if self.connection:
#                 self.logger.info("Starting connection IOLoop")
#                 self.connection.ioloop.start()
                
#         except Exception as e:
#             self.logger.exception(f"IOLoop thread error: {e}")
#             MetricsHandler.inc("py_rmq_exchange_async_errors", 1, subject="ioloop", reason="thread_error")
#         finally:
#             self._ioloop_running = False
#             self.logger.info("IOLoop thread stopped")

#     def stop(self):
#         """Stop the async exchange"""
#         self.logger.warning("Stopping AsyncExchange")
#         MetricsHandler.inc("py_rmq_exchange_async", 1, action="stop")
        
#         self._is_closing = True
#         self.alive = False
#         self.allow_reconnect = False
        
#         if self._heartbeat_timer and self.connection:
#             try:
#                 self.connection.ioloop.remove_timeout(self._heartbeat_timer)
#             except Exception:
#                 pass
        
#         if self.consumer_tag and self.channel and self.channel.is_open:
#             self.logger.info("Cancelling consumer")
#             self.channel.basic_cancel(self.consumer_tag, callback=self._on_cancel_ok)
#         elif self.channel and self.channel.is_open:
#             self._close_channel()
#         elif self.connection and not self.connection.is_closed:
#             self.connection.close()

#     def _on_cancel_ok(self, frame):
#         """Called when consumer is cancelled"""
#         self.logger.info("Consumer cancelled")
#         self._close_channel()

#     def _close_channel(self):
#         """Close the channel"""
#         if self.channel and self.channel.is_open:
#             self.logger.info("Closing channel")
#             self.channel.close()
#         elif self.connection and not self.connection.is_closed:
#             self.connection.close()
    
#     def is_ready(self):
#         """Check if the exchange is ready to publish/consume"""
#         return (
#             self.connection is not None and 
#             not self.connection.is_closed and
#             self.channel is not None and 
#             self.channel.is_open
#         )

