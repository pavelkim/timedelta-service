#!/usr/bin/env python3
# pylint: disable=line-too-long, missing-function-docstring, logging-fstring-interpolation
# pylint: disable=too-many-locals, broad-except, too-many-arguments,
# pylint: disable=raise-missing-from
"""
    RabbitMQ client, non-blocking exchange implementation

"""

import functools
import logging
import threading
import time
import queue

import pika
from pika.connection import Parameters
from pyp8s import MetricsHandler



class AsyncExchange:
    """
    RabbitMQ client, non-blocking exchange implementation

    Attributes:
        host (str): RabbitMQ server host.
        port (int): RabbitMQ server port.
        virtual_host (str): RabbitMQ virtual host.
        username (str): RabbitMQ username.
        password (str): RabbitMQ password.
        exchange (str): Exchange name.
        exchange_type (str): Exchange type.
        durable (bool): Whether the exchange is durable.
        metrics_handler (MetricsHandler): Metrics handler for monitoring.
    """

    def __init__(self,
                 exchange: str,
                 exchange_type: str = 'direct',
                 durable: bool = True,

                 host: str|None = None,
                 port: int = 5672,
                 virtual_host: str = "/",
                 username: str|None = None,
                 password: str|None = None,
                 url: str| None = None,

                prefetch_count: int = 100,

                 thread_name: str = 'AsyncExchangeThread'
        ):

        self.host = host
        self.port = port
        self.virtual_host = virtual_host
        self.username = username
        self.password = password
        self.exchange = exchange
        self.exchange_type = exchange_type
        self.durable = durable
        self.url = url
        self._prefetch_count = prefetch_count

        self.connection_parameters: Parameters | None = None

        self.thread_name = thread_name

        self.logger = logging.getLogger(self.thread_name)

        self._connection: pika.SelectConnection | None = None
        self.channel = None
        self.queue = None
        self._publish_queue = queue.Queue()
        self._stop_event = threading.Event()
        # self._thread = threading.Thread(target=self._run)
        # self._thread.start()

        self.is_publisher = None


    def connect(self):
        """Establish connection to RabbitMQ server and declare exchange."""

        if self.url:
            self.logger.info(f"Using URL to connect to the RabbitMQ server")
            self.connection_parameters = pika.URLParameters(self.url)

        elif self.host:
            self.logger.info(f"Using separate parameters to connect to the RabbitMQ server")

            connection_kwargs = {
                "host": self.host,
                "port": self.port,
                "virtual_host": self.virtual_host,
            }

            if self.username and self.password:
                connection_kwargs['credentials'] = pika.PlainCredentials(self.username, self.password)

            self.connection_parameters = pika.ConnectionParameters(**connection_kwargs)

        self.logger.info(f"Setting up a SelectConnection to RabbitMQ server")

        self._connection = pika.SelectConnection(
            parameters=self.connection_parameters,
            on_open_callback=self.on_connection_open,
            on_open_error_callback=self.on_connection_open_error,
            on_close_callback=self.on_connection_closed)


    def close_connection(self):
        self._consuming = False
        if self._connection.is_closing:
            self.logger.info('Connection is in closing state')

        elif self._connection.is_closed:
            self.logger.info('Connection is already closed')

        else:
            self.logger.info('Closing connection')
            self._connection.close()

        self.logger.info('Closing connection ended')


    def on_connection_open(self, _unused_connection):
        """This method is called by pika once the connection to RabbitMQ has
        been established. It passes the handle to the connection object in
        case we need it, but in this case, we'll just mark it unused.

        :param pika.SelectConnection _unused_connection: The connection

        """
        self.logger.info('Connection opened (callback)')
        self.open_channel()


    def on_connection_open_error(self, _unused_connection, err):
        """This method is called by pika if the connection to RabbitMQ
        can't be established.

        :param pika.SelectConnection _unused_connection: The connection
        :param Exception err: The error

        """
        self.logger.error('Connection open failed, reopening in 5 seconds: %s', err)
        self._connection.ioloop.call_later(5, self._connection.ioloop.stop)


    def open_channel(self):
        """Open a new channel with RabbitMQ by issuing the Channel.Open RPC
        command. When RabbitMQ responds that the channel is open, the
        onchannel_open callback will be invoked by pika.

        """
        self.logger.info('Creating a new channel')
        # TODO: wrap in try/except
        self._connection.channel(on_open_callback=self.onchannel_open)



    def onchannel_open(self, channel):
        """This method is invoked by pika when the channel has been opened.
        The channel object is passed in so we can make use of it.

        Since the channel is now open, we'll declare the exchange to use.

        :param pika.channel.Channel channel: The channel object

        """
        self.logger.info('Channel opened (callback)')
        self.channel = channel
        self.add_onchannel_close_callback()
        self.setup_exchange(self.exchange)


    def add_onchannel_close_callback(self):
        """This method tells pika to call the onchannel_closed method if
        RabbitMQ unexpectedly closes the channel.

        """
        self.logger.info('Adding channel close callback')
        self.channel.add_on_close_callback(self.onchannel_closed)


    def onchannel_closed(self, channel, reason):
        """Invoked by pika when RabbitMQ unexpectedly closes the channel.
        Channels are usually closed if you attempt to do something that
        violates the protocol, such as re-declare an exchange or queue with
        different parameters. In this case, we'll close the connection
        to shutdown the object.

        :param pika.channel.Channel: The closed channel
        :param Exception reason: why the channel was closed

        """
        self.logger.warning(f'Channel {channel} was closed: {reason}')
        self.close_connection()


    def on_connection_closed(self, _unused_connection, reason):
        """This method is invoked by pika when the connection to RabbitMQ is
        closed unexpectedly. Since it is unexpected, we will reconnect to
        RabbitMQ if it disconnects.

        :param pika.connection.Connection connection: The closed connection obj
        :param Exception reason: exception representing reason for loss of
            connection.

        """
        self.logger.warning('Connection closed (callback)')

        self.channel = None

        if self._closing:
            self.logger.info('Connection is being closed within the graceful shutdown probably')
            self.logger.info('Stopping ioloop')
            self._connection.ioloop.stop()
            self.logger.info('Stopped ioloop')
        else:
            self.logger.warning(f'Connection closed, reason: {reason}')
            self.reconnect()


    def reconnect(self):
        """Will be invoked if the connection can't be opened or is
        closed. Indicates that a reconnect is necessary then stops the
        ioloop.

        """
        self.should_reconnect = True
        self.stop()


    def stop(self):
        """Cleanly shutdown the connection to RabbitMQ by stopping the consumer
        with RabbitMQ. When RabbitMQ confirms the cancellation, on_cancelok
        will be invoked by pika, which will then closing the channel and
        connection. The IOLoop is started again because this method is invoked
        when CTRL-C is pressed raising a KeyboardInterrupt exception. This
        exception stops the IOLoop which needs to be running for pika to
        communicate with RabbitMQ. All of the commands issued prior to starting
        the IOLoop will be buffered but not processed.

        """
        if self._closing:
            self.logger.info('Already stopping, ignoring stop request')
            return

        self._closing = True
        self.logger.info('Stopping')
        if self._consuming:
            self.stop_consuming()
            self._connection.ioloop.start()
        else:
            self._connection.ioloop.stop()
        self.logger.info('Stopped')
        
    def stop_consuming(self):
        """Tell RabbitMQ that you would like to stop consuming by sending the
        Basic.Cancel RPC command.

        """
        if self.channel:
            self.logger.info('Sending a Basic.Cancel RPC command to RabbitMQ')
            cb = functools.partial(
                self.on_cancelok, userdata=self._consumer_tag)
            self.channel.basic_cancel(self._consumer_tag, cb)

    def on_cancelok(self, _unused_frame, userdata):
        """This method is invoked by pika when RabbitMQ acknowledges the
        cancellation of a consumer. At this point we will close the channel.
        This will invoke the onchannel_closed method once the channel has been
        closed, which will in-turn close the connection.

        :param pika.frame.Method _unused_frame: The Basic.CancelOk frame
        :param str|unicode userdata: Extra user data (consumer tag)

        """
        self._consuming = False
        self.logger.info(
            'RabbitMQ acknowledged the cancellation of the consumer: %s',
            userdata)
        self.closechannel()


    def closechannel(self):
        """Call to close the channel with RabbitMQ cleanly by issuing the
        Channel.Close RPC command.

        """
        self.logger.info('Closing the channel')
        self.channel.close()


    def setup_exchange(self, exchange_name):
        """Setup the exchange on RabbitMQ by invoking the Exchange.Declare RPC
        command. When it is complete, the on_exchange_declareok method will
        be invoked by pika.

        :param str|unicode exchange_name: The name of the exchange to declare

        """
        self.logger.info(f'Declaring exchange: {exchange_name}')
        # Note: using functools.partial is not required, it is demonstrating
        # how arbitrary data can be passed to the callback when it is called
        cb = functools.partial(self.on_exchange_declareok, userdata=exchange_name)
        self.channel.exchange_declare(
            exchange=exchange_name,
            exchange_type=self.exchange_type,
            callback=cb)


    def on_exchange_declareok(self, _unused_frame, userdata):
        """Invoked by pika when RabbitMQ has finished the Exchange.Declare RPC
        command.

        :param pika.Frame.Method unused_frame: Exchange.DeclareOk response frame
        :param str|unicode userdata: Extra user data (exchange name)

        """
        self.logger.info(f'Exchange declared: {userdata}')
        self.setup_queue(self.queue)


    def setup_queue(self, queue):
        """Setup the queue on RabbitMQ by invoking the Queue.Declare RPC
        command. When it is complete, the on_queue_declareok method will
        be invoked by pika.

        :param str|unicode queue: The name of the queue to declare.

        """
        self.logger.info(f'Declaring queue: {queue}')
        cb = functools.partial(self.on_queue_declareok, userdata=queue)
        self.channel.queue_declare(queue=queue, callback=cb)


    def on_queue_declareok(self, _unused_frame, userdata):
        """Method invoked by pika when the Queue.Declare RPC call made in
        setup_queue has completed. In this method we will bind the queue
        and exchange together with the routing key by issuing the Queue.Bind
        RPC command. When this command is complete, the on_bindok method will
        be invoked by pika.

        :param pika.frame.Method _unused_frame: The Queue.DeclareOk frame
        :param str|unicode userdata: Extra user data (queue name)

        """
        queue = userdata
        self.logger.info(f'Binding {self.exchange} to {queue} with {self.routing_key}')
        cb = functools.partial(self.on_bindok, userdata=queue)

        if self.routing_keys:
            for routing_key_item in self.routing_keys:
                self.logger.info(f"Binding RabbitMQ exclusive queue={self.queue} to exchange={self.exchange} with routing_key={routing_key_item}")
                self.channel.queue_bind(queue=self.queue, exchange=self.exchange, routing_key=routing_key_item, callback=cb)
                MetricsHandler.inc("py_rmq_exchange", 1, mode="consumer", action="bound_queue")
        else:
            self.logger.info(f"Binding RabbitMQ exclusive queue={self.queue} to exchange={self.exchange} with routing_key={self.routing_key}")
            self.channel.queue_bind(queue=self.queue, exchange=self.exchange, routing_key=self.routing_key, callback=cb)
            MetricsHandler.inc("py_rmq_exchange", 1, mode="consumer", action="bound_queue")


        # self.channel.queue_bind(
        #     queue,
        #     self.exchange,
        #     routing_key=self.routing_key,
        #     callback=cb)

    def on_bindok(self, _unused_frame, userdata):
        """Invoked by pika when the Queue.Bind method has completed. At this
        point we will set the prefetch count for the channel.

        :param pika.frame.Method _unused_frame: The Queue.BindOk response frame
        :param str|unicode userdata: Extra user data (queue name)

        """
        self.logger.info(f'Queue bound: {userdata}')
        self.set_qos()

    def set_qos(self):
        """This method sets up the consumer prefetch to only be delivered
        one message at a time. The consumer must acknowledge this message
        before RabbitMQ will deliver another one. You should experiment
        with different prefetch values to achieve desired performance.

        """
        self.channel.basic_qos(
            prefetch_count=self._prefetch_count, callback=self.on_basic_qos_ok)


    def on_basic_qos_ok(self, _unused_frame):
        """Invoked by pika when the Basic.QoS method has completed. At this
        point we will start consuming messages by calling start_consuming
        which will invoke the needed RPC commands to start the process.

        :param pika.frame.Method _unused_frame: The Basic.QosOk response frame

        """
        self.logger.info(f'QOS set to: {self._prefetch_count}')
        # self.start_consuming()


    def start_consuming(self):
        """This method sets up the consumer by first calling
        add_on_cancel_callback so that the object is notified if RabbitMQ
        cancels the consumer. It then issues the Basic.Consume RPC command
        which returns the consumer tag that is used to uniquely identify the
        consumer with RabbitMQ. We keep the value to use it when we want to
        cancel consuming. The on_message method is passed in as a callback pika
        will invoke when a message is fully received.

        """
        self.logger.info('Issuing consumer related RPC commands')
        
        # TODO: rename the method to add_on_consumer_cancel_callback or something else
        self.add_on_cancel_callback()

        on_message_callback = functools.partial(self.on_message, args=(threads))
        self._consumer_tag = self.channel.basic_consume(queue=self.queue, on_message_callback=on_message_callback)

        self.was_consuming = True
        self._consuming = True


    def add_on_cancel_callback(self):
        """Add a callback that will be invoked if RabbitMQ cancels the consumer
        for some reason. If RabbitMQ does cancel the consumer,
        on_consumer_cancelled will be invoked by pika.

        """
        self.logger.info('Adding consumer cancellation callback')
        self.channel.add_on_cancel_callback(self.on_consumer_cancelled)


    def on_consumer_cancelled(self, method_frame):
        """Invoked by pika when RabbitMQ sends a Basic.Cancel for a consumer
        receiving messages.

        :param pika.frame.Method method_frame: The Basic.Cancel frame

        """
        self.logger.info('Consumer was cancelled remotely, shutting down: %r', method_frame)
        self.channel.close()


    def on_message(self, _unusedchannel, basic_deliver, properties, body):
        """Invoked by pika when a message is delivered from RabbitMQ. The
        channel is passed for your convenience. The basic_deliver object that
        is passed in carries the exchange, routing key, delivery tag and
        a redelivered flag for the message. The properties passed in is an
        instance of BasicProperties with the message properties and the body
        is the message that was sent.

        :param pika.channel.Channel _unusedchannel: The channel object
        :param pika.Spec.Basic.Deliver: basic_deliver method
        :param pika.Spec.BasicProperties: properties
        :param bytes body: The message body

        """
        self.logger.info(f'Received message # {basic_deliver.delivery_tag} from {properties.app_id}: {body}')
        self.acknowledge_message(basic_deliver.delivery_tag)

    def acknowledge_message(self, delivery_tag):
        """Acknowledge the message delivery from RabbitMQ by sending a
        Basic.Ack RPC method for the delivery tag.

        :param int delivery_tag: The delivery tag from the Basic.Deliver frame

        """
        self.logger.info('Acknowledging message %s', delivery_tag)
        self.channel.basic_ack(delivery_tag)


    def _on_message_callback(self, channel, method, properties, body):
        self.logger.info(f"Received inbound event: channel={channel}, method={method}, properties={properties}, body={body}")
        self.logger.debug(f"Additional parameters: args={self.args}, kwargs={self.kwargs}")

        self.logger.debug(f"Received message: exchange={method.exchange} body={body}")
        MetricsHandler.inc("py_rmq_exchange", 1, mode="consumer", func="_on_message_callback")
        MetricsHandler.inc("py_rmq_exchange", 1, mode="consumer", event="incoming_message")


    def setup_consumer(self, exchange, on_message_callback,
        queue="", exclusive=True, auto_ack=True, exchange_type='fanout', durable=False,
        routing_key=None, routing_keys=None,
        prefetch_size=0, prefetch_count=0, global_qos=False,
        exchange_declare_arguments=None, queue_declare_arguments=None):
        """
        Set up a RabbitMQ consumer with the specified parameters.

        This method configures the consumer by declaring the exchange and queue, 
        binding the queue to the exchange with the provided routing key(s), 
        and setting up Quality of Service (QoS) parameters. 
        It also registers the message callback and starts consuming messages from the queue.

        Args:
            exchange (str): Name of the exchange to consume from.
            on_message_callback (callable): Callback function to handle incoming messages.
            queue (str, optional): Name of the queue to declare. Defaults to "".
            exclusive (bool, optional): Whether the queue should be exclusive. Defaults to True.
            auto_ack (bool, optional): Whether to automatically acknowledge messages. Defaults to True.
            exchange_type (str, optional): Type of the exchange (e.g., 'fanout', 'direct'). Defaults to 'fanout'.
            durable (bool, optional): Whether the exchange and queue should be durable. Defaults to False.
            routing_key (str, optional): Routing key for binding the queue. Defaults to None.
            routing_keys (list, optional): List of routing keys for binding the queue. Defaults to None.
            prefetch_size (int, optional): Prefetch window size in bytes. Defaults to 0.
            prefetch_count (int, optional): Prefetch message count. Defaults to 0.
            global_qos (bool, optional): Whether QoS settings should apply to the entire connection. Defaults to False.
            exchange_declare_arguments (dict, optional): Additional arguments for exchange declaration. Defaults to None.
            queue_declare_arguments (dict, optional): Additional arguments for queue declaration. Defaults to None.
        """
        

        self.logger.info(f"Setting up RabbitMQ consumer exchange={exchange} on_message_callback={on_message_callback}")
        MetricsHandler.inc("py_rmq_exchange", 1, mode="consumer", func="setup_consumer")

        # on_message_callback = functools.partial(self.on_message, args=(threads))
        # self._consumer_tag = self.channel.basic_consume(queue=self.queue, on_message_callback=on_message_callback)

        # self.was_consuming = True
        # self._consuming = True

        if self.is_publisher:
            raise Exception("Already a publisher, can't setup consuming")

        self.is_consumer = True
        self.consumer_kwargs = locals()
        self.consumer_kwargs.pop('self')
        
        self.routing_key = routing_key
        self.routing_keys = routing_keys

        self.exchange = exchange
        self.queue = queue
        self.exclusive = exclusive
        self.auto_ack = auto_ack
        self.exchange_type = exchange_type
        self.on_message_callback = on_message_callback
        self.durable = durable

        self.prefetch_size = prefetch_size
        self.prefetch_count = prefetch_count
        self.global_qos = global_qos

        if exchange_declare_arguments is None:
            self.exchange_declare_arguments = {}
        else:
            self.exchange_declare_arguments = exchange_declare_arguments

        if queue_declare_arguments is None:
            self.queue_declare_arguments = {}
        else:
            self.queue_declare_arguments = queue_declare_arguments

        # self.logger.info(f"Declaring RabbitMQ fanout exchange")
        # self.channel.exchange_declare(exchange=self.exchange, exchange_type=self.exchange_type, durable=self.durable, arguments=self.exchange_declare_arguments)
        # MetricsHandler.inc("py_rmq_exchange", 1, mode="consumer", action="declared_exchange")

        # self.logger.info(f"Declaring RabbitMQ exclusive queue")
        # declared_queue = self.channel.queue_declare(queue=self.queue, durable=self.durable, exclusive=self.exclusive, arguments=self.queue_declare_arguments)
        # self.queue = declared_queue.method.queue
        # MetricsHandler.inc("py_rmq_exchange", 1, mode="consumer", action="declared_queue")

        # self.logger.info(f"Setting up QoS for RabbitMQ queue")
        # self.channel.basic_qos(prefetch_size=self.prefetch_size, prefetch_count=self.prefetch_count, global_qos=self.global_qos)

        self.logger.info(f"Calling connect method to establish connection")
        self.connect()

        self.logger.info(f"Starting ioloop to process events")
        self._connection.ioloop.start()
        self.logger.info(f"Started ioloop to process events")

        # if routing_keys:
        #     for routing_key_item in routing_keys:
        #         self.logger.info(f"Binding RabbitMQ exclusive queue={self.queue} to exchange={self.exchange} with routing_key={routing_key_item}")
        #         self.channel.queue_bind(queue=self.queue, exchange=self.exchange, routing_key=routing_key_item)
        #         MetricsHandler.inc("py_rmq_exchange", 1, mode="consumer", action="bound_queue")
        # else:
        #     self.logger.info(f"Binding RabbitMQ exclusive queue={self.queue} to exchange={self.exchange} with routing_key={routing_key}")
        #     self.channel.queue_bind(queue=self.queue, exchange=self.exchange, routing_key=routing_key)
        #     MetricsHandler.inc("py_rmq_exchange", 1, mode="consumer", action="bound_queue")

        # TODO: rename the method to add_on_consumer_cancel_callback or something else
        self.add_on_cancel_callback()

        self.logger.info(f"Configuring RabbitMQ basic consume with queue={self.queue}")
        on_message_callback = functools.partial(self._on_message_callback, args=())

        self.consumer_tag = self.channel.basic_consume(
            queue=self.queue,
            auto_ack=self.auto_ack,
            on_message_callback=on_message_callback,
        )


    def setup_publisher(self, exchange, publish_queue=None, exchange_type='fanout',
        exchange_declare_arguments=None):

        self.logger.info(f"Setting up RabbitMQ publisher exchange={exchange} publish_queue={publish_queue}")
        MetricsHandler.inc("py_rmq_exchange", 1, mode="publisher", func="setup_publisher")

        if self.is_consumer:
            raise Exception("Already a consumer, can't setup publishing")

        self.is_publisher = True
        self.publisher_kwargs = locals()
        self.publisher_kwargs.pop('self')

        if publish_queue is not None:
            self.publish_queue = publish_queue

        self.exchange = exchange
        self.exchange_type = exchange_type

        if exchange_declare_arguments is None:
            self.exchange_declare_arguments = {}
        else:
            self.exchange_declare_arguments = exchange_declare_arguments

        self.logger.info(f"Declaring RabbitMQ fanout exchange")
        self.channel.exchange_declare(exchange=self.exchange, exchange_type=self.exchange_type, arguments=self.exchange_declare_arguments)
        MetricsHandler.inc("py_rmq_exchange", 1, mode="publisher", action="declared_exchange")
        # self.channel.queue_declare(queue=queue)
